Exercice 10 : Récapitulons

Maintenant que vous connaissez les variables, conditions, boucles , opérateurs logiques, etc de javascript,
vous pouvez réaliser un petit jeu simple :

Jeu du plus ou moins

L'ordinateur va choisir un nombre secret au hasard entre 1 et 100 et vous demander de trouver ce nombre.
En fonction du nombre que vous entrez, il va vous dire s'il est supérieur ou inférieur au nombre secret.
Tant que le nombre entré est différent du nombre secret, il vous demandera d'entrer un nombre.
Si vous trouvez le nombre secret, la partie s'arrête et vous avez gagné.

Si vous souhaitez aller plus loin, vous pouvez créer un compteur qui vous dira en combien de coups vous avez trouvé le nombre secret, donner un choix de difficulté, etc...
