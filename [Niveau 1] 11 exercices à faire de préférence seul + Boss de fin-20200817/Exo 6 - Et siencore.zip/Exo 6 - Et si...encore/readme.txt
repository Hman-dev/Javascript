Exercice 6 : Et si...encore

Votre employeur, une boite de nuit un peu particulière ,
n'est pas satisfait. Il dit que votre programme laisse rentrer n'importe qui!
Il vous donne les instructions suivantes pour améliorer votre programme:
- si la personne a moins de 18 ans, elle ne rentre pas.
- si elle a 18 ans ou plus, elle peut rentrer.
- si elle a plus de 70 ans, elle ne peut pas entrer(la nuit dernière, 2 hanches cassées et une bataille de déhambulateur ont eu lieu )
- si la personne entre autre chose qu'un nombre, elle n'entre pas

Le programme doit demander l'age de la personne puis lui afficher l'acceptation ou le refus.

Regardez du coté de prompt() , ça pourrait vous être utile et pour éviter les fraudeurs,
cherchez à tester si les valeurs entrées sont numériques.
