Exercice 1 : Ma première page avec javascript

Le fichier HTML est un peu terne comme ça , rendez le actif en affichant un bon vieux Helloworld dans une boite de dialogue au chargement de la page.
Souvenez vous que le javascript peut s'écrire à différents endroits.
