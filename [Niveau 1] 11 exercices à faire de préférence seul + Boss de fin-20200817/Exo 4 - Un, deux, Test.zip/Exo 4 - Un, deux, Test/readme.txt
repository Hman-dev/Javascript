Exercice 4 : Un, deux, Test

Vous faites vos courses au supermarché Variables & Co, et vous souhaitez comparer certains produits de la liste suivante :

a = 2
b = "2"
c = 14
d = 1 + "4"

Pour cela vous avez à votre disposition les outils de comparaison de javascript :

==
===
!=
!==
<
<=
>
>=

Testez ensuite les produits de ce supermarché :

a est égal à la valeur de b ?
a est différent en valeur et en type à b ?
c est supérieur ou égal à a ?
c est différent en valeur à d ?
c est égal en valeur et en type à d ?
