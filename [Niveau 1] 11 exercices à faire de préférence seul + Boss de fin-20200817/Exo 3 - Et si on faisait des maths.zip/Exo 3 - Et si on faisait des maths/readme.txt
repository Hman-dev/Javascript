Exercice 3 : Et si on faisait des maths

Retour à l'école , le prof vous donne  les éléments suivants :
 a = 12 , b = 25 , c = 3
affichez les résultats des opérations suivantes dans la console:

a + b
a * b
a / c
a % c

Maintenant que vous êtes un supercalculateur, vous pouvez chercher la réponse à La Grande Question sur la vie, l'univers et le reste :
(a+c)*c/b*10+a*2
