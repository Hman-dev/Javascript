Exercice 2 : Les variables

Dans javascript vous pouvez créer un grand nombre de variables qui sont chacune d'un certain type .
Dans cet exercice vous allez créer des variables de types :
- numérique (positifs, négatifs ou à virgule)
- chaines de caractères
- booléens

Affichez les ensuite dans la console avec leur type (fonction typeof()).
