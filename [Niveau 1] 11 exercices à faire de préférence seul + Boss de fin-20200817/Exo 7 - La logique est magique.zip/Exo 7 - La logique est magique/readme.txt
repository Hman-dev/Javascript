Exercice 7 : la logique est magique

Votre personnage du célèbre jeu world of warwizardhammertankdiablo online doit porter certains des
éléments suivants pour pouvoir tuer les boss du donjon :

- casque
- epee
- bouclier

Ici, tout se passe dans la console. Vous devez remplir, dans le fichier script.js , les conditions
correspondantes aux commentaires inscrits avec des opérateurs logiques :
EXEMPLE :
// "si A et B sont vrai alors... sinon ..." se traduit par :

if(A && B){
    ...
} else {
    ...
}

Si vous le souhaitez , vous pouvez améliorer cet exercice en y ajoutant des éléments, des choix, etc
