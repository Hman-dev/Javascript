# Objectif
Modifier la structure DOM avec addEventListener()

# Enoncé
Créez une page contenant un bouton dont le texte est "Cliquez-moi" et ayant comme id la valeur "bouton1".

À l'aide d'addEventListener(), faites en sorte que lorsque l'utilisateur clique sur ce bouton, son texte passe de "Cliquez-moi" à "Vous m'avez cliqué". Si l'utilisateur clique à nouveau sur ce bouton, le texte redevient "Cliquez-moi". 
