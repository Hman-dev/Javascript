# Objectif
Manipuler les boucles for et do..while.

# Énoncé 
1) Ecrire une procédure qui permet d'afficher la table de multiplication d'un nombre entier n :
La valeur de n sera demandée à l’utilisateur via une boite de dialogue et sera passée comme argument à la procédure.
2) En cas de saisie d'un nombre non entier le script boucle et redemande à l'utilisateur de saisir une nouvelle valeur.
3) Utiliser les boucles imbriquées pour afficher l'ensemble des tables de multiplication pour i <= n. Par exemple si l'utilisateur saisit le nombre 4, on affiche alors les tables de multiplication des nombres 1, puis 2, puis 2 et enfin 4.

Améliorations :
L'affichage de la table de multiplication résultat pour être directement réalisé à partir de code HTML (un tableau) généré par le script.
