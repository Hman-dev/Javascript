# Objectifs
Modifier la couleur des différents éléments de la page directement en javascript

# Enoncé
En modifiant le fichier index.html vous devez faire en sorte de rajouter le code javascript nécessaire afin d'obtenir tous les comportements suivants :
1) En cliquant sur le bouton "Modifier fond", le fond du bloc devient jaune
2) En cliquant sur le bouton "Modifier texte", tout le texte devient noir
3) En survolant l'un des deux paragraphes, la couleur du texte de ce paragraphe (uniquement) devient blanche. En quittant la zone, le texte récupère sa couleur originelle.

Exemples d'utilisation :

Voir les screenshots fournis.
