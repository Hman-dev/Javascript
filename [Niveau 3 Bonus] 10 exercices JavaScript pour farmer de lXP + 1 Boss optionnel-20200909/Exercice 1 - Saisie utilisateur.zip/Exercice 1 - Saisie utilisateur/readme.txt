# Objectif
Interaction utilisateur via les boites de dialogue alert, confirm et prompt.

# Énoncé 
Créer un document html qui contient 2 boutons.

# Consignes
1)Ecrire un script qui affiche le message "Hello World" après le clic sur le premier bouton.
2) Lors du clic sur le  deuxième bouton  demander à l'utilisateur de saisir son nom. Demander ensuite une confirmation du nom de l'utilisateur. Si le nom est confirmé, afficher ce dernier dans une boîte de dialogue.
Exemple d’exécution :
Voir les 3 screenshots présents dans l'archive.