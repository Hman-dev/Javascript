# Objectif
Manipuler les chaines de caractères.

# Travail à faire
1) Ecrire une fonction qui permet de tester si une chaîne de caractère passée en paramètre commence par une lettre majuscule ou minuscule positionnée entre 'a' et 'd'.
2) Ecrire une fonction qui renvoie true lorsqu'une chaîne contient un seul caractère '@' sinon renvoie false.
3) Ecrire une fonction qui renvoie true lorsqu'une chaîne contient au moins un chiffre sinon renvoie false.
4) Ecrire une fonction qui remplace les chiffres par le caractère '*'
5) Créer un script qui va utiliser (à votre convenance) ces fonctions. 

Pensez bien à écrire des tests pour chaque questions afin de valider votre travail.
Si vous n'arrivez pas à tout faire du premier coup, ce n'est pas grave. Vous pourrez soit y revenir plus tard, soit vous faire aider par vos camarades.

Exemple d’exécution : 
Voir screenshot fourni.
