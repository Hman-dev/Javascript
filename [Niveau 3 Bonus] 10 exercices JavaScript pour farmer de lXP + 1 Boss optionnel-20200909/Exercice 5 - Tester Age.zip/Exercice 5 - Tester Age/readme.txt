Le but de cet exercice est simple : vous demanderez à l'utilisateur son âge et en fonction de sa réponse vous afficherez à travers une popup un message personnalisé.

Consignes :
Vous ferez ceci en javascript vanilla.
Vous commencerez par demander l'âge de l'utilisateur à travers une popup de saisie
En fonction de sa réponse vous afficherez les messages suivants :
Si l'utilisateur est mineur --> "Vous n'avez pas le droit de venir sur ce site"
Si l'utilisateur a entre 18 et 50 ans --> "Vous êtes majeur mais pas encore senior, la vie est belle"
Si l'utilisateur a entre 51 et 60 ans --> "Vous êtes senior mais pas encore retraité"
Si l'utilisateur a plus de 60 ans --> "Vous êtes retraité, profitez de votre temps libre !"

Améliorations :
Que se passe-t-il si vous saisissez autre chose qu'un nombre ? Ou une valeur négative ?
Améliorez le contrôle de la saisie ainsi que les conditions de tests pour fiabiliser le code.